# Tristan Wojt | ACL Recovery

A responsive personal website about Tristan's college football and ACL recovery journey. It is a static site built with plain HTML and CSS; there is no build step or package installation.

## Files to publish

- `index.html` — page content
- `styles.css` — responsive styles
- `football-photo.png` — hero image

Keep these three files together in the repository root so the relative image and stylesheet links work on GitHub Pages.

## Preview locally

Open `index.html` in a browser. The site uses Google Fonts when a visitor is online and falls back to system fonts otherwise.

## Publish with GitHub Pages

For the existing `twoo480.github.io/portfolio` address:

1. Add `index.html`, `styles.css`, `football-photo.png`, and this `README.md` to the root of the `portfolio` repository.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and the `/ (root)` folder, then save.
5. After GitHub Pages finishes deploying, open `https://twoo480.github.io/portfolio/`.

If the repository uses a different default branch or already has a Pages workflow, keep its existing deployment configuration and publish the files through that setup.
